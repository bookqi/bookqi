import Vue from 'vue'
import Router from 'vue-router'
import index from '../pages/index'
import man from '../pages/man'
import weman from '../pages/weman'
import tuijian from '../pages/tuijian'
import faxians from '../pages/faxians'

Vue.use(Router)

export default new Router({
  routes: [
    {
      path: '/',
      name: 'tuijian',
      component: tuijian
    },
    {
      path: '/index/:type',
      name: 'index',
      component: index
    },
    {
      path: '/man/:type',
      name: 'man',
      component: man
    },
    {
      path: '/weman/:type',
      name: 'weman',
      component: weman
    },
    {
      path: '/tuijian/:type',
      name: 'tuijian',
      component: tuijian
    },
    {
      path: '/faxians/:type',
      name: 'faxians',
      component: faxians
    }
  ]
})
